# slidify_tutorial

- Basic tutorial for making decks in slidify
- This is a work in progress
