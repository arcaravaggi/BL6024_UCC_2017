/*
 *  /MathJax/jax/output/HTML-CSS/fonts/STIX/General/Bold/GeometricShapes.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["STIXGeneral-bold"],{9651:[811,127,1145,35,1110],9655:[791,284,1043,70,1008],9661:[811,127,1145,35,1110],9665:[791,284,1043,35,973],9674:[795,289,790,45,745],9708:[811,127,1145,35,1110]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/General/Bold/GeometricShapes.js");

